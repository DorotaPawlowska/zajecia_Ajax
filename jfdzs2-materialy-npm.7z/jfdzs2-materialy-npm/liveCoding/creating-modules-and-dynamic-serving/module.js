function add(a,b) {
    return a+b;
}

var PI = 3.14;

    module.exports = {
        add: add,
        PI: PI
    }