var http = require('http');
var url = require('url');

var add = require('./module').add;

http.createServer(function (request, response) {
    var query = url.parse(request.url, true).query;
    var result = add(parseInt(query.a), parseInt(query.b)).toString();
    response.end(result);
}).listen(3000);

